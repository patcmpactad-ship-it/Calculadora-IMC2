const form = document.querySelector("#imc-form");
const weightInput = document.querySelector("#weight");
const heightInput = document.querySelector("#height");
const resultSection = document.querySelector("#result");
const imcValue = document.querySelector("#imc-value");
const resultMessage = document.querySelector("#result-message");
const resetButton = document.querySelector("#reset-button");

// Aceita números inteiros ou decimais, usando vírgula ou ponto.
const numberPattern = /^\d+(?:[.,]\d+)?$/;

function parseField(input) {
  const value = input.value.trim();
  if (!numberPattern.test(value)) return null;
  return Number(value.replace(",", "."));
}

function showError(input, message) {
  const error = document.querySelector(`#${input.id}-error`);
  error.textContent = message;
  input.closest(".input-wrap").classList.toggle("invalid", Boolean(message));
}

function clearErrors() {
  showError(weightInput, "");
  showError(heightInput, "");
}

function calculateIMC(weight, heightCm) {
  const heightM = heightCm / 100;
  return weight / (heightM * heightM);
}

form.addEventListener("submit", event => {
  event.preventDefault();
  clearErrors();
  resultSection.hidden = true;

  const weight = parseField(weightInput);
  const height = parseField(heightInput);
  let valid = true;

  if (weight === null || weight <= 0 || weight > 500) {
    showError(weightInput, "Digite um peso válido, maior que zero.");
    valid = false;
  }
  if (height === null || height <= 0 || height > 300) {
    showError(heightInput, "Digite uma altura válida em centímetros.");
    valid = false;
  }
  if (!valid) return;

  const imc = calculateIMC(weight, height);
  imcValue.textContent = imc.toFixed(2).replace(".", ",");
  resultMessage.textContent =
    "Cálculo concluído. O número é uma referência matemática; em adolescentes, a avaliação depende da idade e das curvas de crescimento.";
  resultSection.hidden = false;
});

[weightInput, heightInput].forEach(input => {
  input.addEventListener("input", () => {
    showError(input, "");
    resultSection.hidden = true;
  });
});

resetButton.addEventListener("click", () => {
  clearErrors();
  resultSection.hidden = true;
});

form.addEventListener("reset", () => {
  // O evento reset ocorre antes de os campos serem limpos pelo navegador.
  setTimeout(() => {
    clearErrors();
    resultSection.hidden = true;
  }, 0);
});
